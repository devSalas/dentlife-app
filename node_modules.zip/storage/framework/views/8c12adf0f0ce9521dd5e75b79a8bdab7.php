<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">

    <link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"
/>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

<style>
    html,body{
        scroll-behavior: smooth;
    }
    h1{
        font-family: 
    }



    h1,h2 {
    font-family: "Montserrat", sans-serif;
    font-optical-sizing: auto;
    font-weight:bold;
    font-style: normal;
    }
</style>
<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="scroll-smooth">
    <?php echo $__env->yieldContent('content'); ?>

    <footer class="bg-[#1d1818] text-white">
        <section class="p-12 flex md:flex-row flex-col justify-between gap-12">
            <div class="max-w-60 bg-white ">
              
                <img class="w-full" src="<?php echo e(asset('img/logo-dent-life-web-2.webp')); ?>" alt="">
            </div>
            <div class="grid md:grid-cols-3 gap-12">
                <div>
                    <h5 class="text-xl">Llámanos</h5>
                    <p>+51 999 032 000</p>
                </div>
                <div>
                    <h5 class="text-xl">Visitanos</h5>
                    <p>Av. Gran Chimú Nº 753 Urb. Zarate S.J.L.</p>
                </div>
                <div>
                    <h5 class="text-xl">Horario</h5>
                    <p>Lunes - Sabado: 9:00 - 20:45</p>
                    <p>Domingo: Previa cita</p>
                </div>
            </div>

        </section>
        <section class="p-6 border-t border-[#f2efe9]">
            <p class="text-center">
                © Dent Life 2024. Todos los derechos reservados.
            </p>
        </section>
    </footer>

    <?php if (isset($component)) { $__componentOriginald23fed4c319d5529f32fd1bae5fa1ff5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald23fed4c319d5529f32fd1bae5fa1ff5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.w','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('w'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald23fed4c319d5529f32fd1bae5fa1ff5)): ?>
<?php $attributes = $__attributesOriginald23fed4c319d5529f32fd1bae5fa1ff5; ?>
<?php unset($__attributesOriginald23fed4c319d5529f32fd1bae5fa1ff5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald23fed4c319d5529f32fd1bae5fa1ff5)): ?>
<?php $component = $__componentOriginald23fed4c319d5529f32fd1bae5fa1ff5; ?>
<?php unset($__componentOriginald23fed4c319d5529f32fd1bae5fa1ff5); ?>
<?php endif; ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\dentlife-peru\dentlife\resources\views/layouts/public.blade.php ENDPATH**/ ?>