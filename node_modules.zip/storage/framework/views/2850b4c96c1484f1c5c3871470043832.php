<div>
    blog
</div><?php /**PATH C:\xampp\htdocs\dentlife-peru\dentlife\resources\views/blog.blade.php ENDPATH**/ ?>