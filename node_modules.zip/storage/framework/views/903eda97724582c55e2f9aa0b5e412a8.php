<div class="pulse size-16 rounded-full bg-green-500 fixed bottom-8 right-8 z-40">
</div>


<style>
  .uno {
    animation: uno .2s 30s both;
  }

  @keyframes uno {
    from {
      opacity: 0;
    }
  }

  .pulse {
    animation: pulse-animate 1s infinite;
  }

  @keyframes pulse-animate {
    to {
      transform: scale(1.5);
      opacity: 0;
    }
  }
</style>

<button id="btn-w" class="size-16 rounded-full shadow-lg bg-green-500 flex items-center justify-center fixed z-50 bottom-8 right-8">
  <div class="w-icon">
    <?php if (isset($component)) { $__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.w-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('w-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1)): ?>
<?php $attributes = $__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1; ?>
<?php unset($__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1)): ?>
<?php $component = $__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1; ?>
<?php unset($__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1); ?>
<?php endif; ?>
  </div>
  <div style="display: none;" class="x-icon">
    <?php if (isset($component)) { $__componentOriginal6d98250683038ce1d845de61328ff59e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6d98250683038ce1d845de61328ff59e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.x-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('x-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6d98250683038ce1d845de61328ff59e)): ?>
<?php $attributes = $__attributesOriginal6d98250683038ce1d845de61328ff59e; ?>
<?php unset($__attributesOriginal6d98250683038ce1d845de61328ff59e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6d98250683038ce1d845de61328ff59e)): ?>
<?php $component = $__componentOriginal6d98250683038ce1d845de61328ff59e; ?>
<?php unset($__componentOriginal6d98250683038ce1d845de61328ff59e); ?>
<?php endif; ?>
  </div>
</button>

<div class="uno size-4 flex justify-center items-center rounded-full bg-red-500 fixed z-50 pointer-events-none bottom-20 right-8 text-white text-xs">1</div>

<section id="ws" class="bg-white w-96 rounded-xl shadow-lg fixed bottom-28 right-8 overflow-hidden hidden">
  <header class="bg-green-500 px-4 py-6 flex items-center gap-4">
    <div>
      <?php if (isset($component)) { $__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.w-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('w-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1)): ?>
<?php $attributes = $__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1; ?>
<?php unset($__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1)): ?>
<?php $component = $__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1; ?>
<?php unset($__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1); ?>
<?php endif; ?>
    </div>
    <div>
      <div class="text-white text-lg">Iniciar una conversación</div>
      <div class="text-white text-sm">¡Hola! Haga clic en uno de nuestros miembros a continuación para chatear WhatsApp</div>
    </div>
  </header>
  <div class="px-4 py-6">
    <a target="_blank" href="https://api.whatsapp.com/send?phone=51999032000" rel="nofollow noopener noreferrer" class="bg-neutral-100 border-l-2 border-green-500 p-4 rounded flex gap-4 hover:shadow-lg transition-shadow duration-300">
      <div><?php if (isset($component)) { $__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.w-icon','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('w-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1)): ?>
<?php $attributes = $__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1; ?>
<?php unset($__attributesOriginal8a5b1c59c641c68e44d0e965d1e030f1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1)): ?>
<?php $component = $__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1; ?>
<?php unset($__componentOriginal8a5b1c59c641c68e44d0e965d1e030f1); ?>
<?php endif; ?></div>
      <div>
        <div class="text-sm">Dent Life</div>
        <div class="text-neutral-400 text-xs">Escríbenos para una cualquier consulta</div>
      </div>
    </a>
  </div>
</section>

<style>
  [data-ws] {
    display: block;
    animation: ws-active .4s both;
  }

  @keyframes ws-active {
    from {
      opacity: 0;
      transform: translateY(100px);
    }
  }
</style>

<script>
  const btnW = document.getElementById("btn-w")
  const ws = document.getElementById("ws")
  const wIcon = document.querySelector(".w-icon")
  const xIcon = document.querySelector(".x-icon")
  const uno = document.querySelector(".uno")

  btnW.addEventListener("click", () => {

    if (ws.hasAttribute('data-ws')) {
      ws.removeAttribute('data-ws');
      wIcon.style.display = "block"
      xIcon.style.display = "none"
    } else {
      ws.setAttribute('data-ws', '');
      wIcon.style.display = "none"
      xIcon.style.display = "block"
      uno.style.display = "none"
    }

  })
</script><?php /**PATH C:\xampp\htdocs\dentlife-peru\dentlife\resources\views/components/w.blade.php ENDPATH**/ ?>